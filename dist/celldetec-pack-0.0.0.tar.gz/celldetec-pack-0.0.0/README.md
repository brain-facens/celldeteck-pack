

# Cellphone detection using YOLOv5
Python package for cell phone detection using YOLOv5-based custom model